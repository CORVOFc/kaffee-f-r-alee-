(function() {
    "use strict";
    const $ = seletor => document.querySelector(seletor);
    const estado = {
        etapa: 1,
        tipoEntrega: "retirada_na_loja",
        endereco: null,
        observacoes: "",
        pagamento: null
    };
    let sessao;
    let itens = [];
    const dinheiro = valor => Number(valor || 0).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
    const aviso = (texto, erro = false) => {
        const alvo = $("#checkout-aviso");
        if (alvo) {
            alvo.textContent = texto;
            alvo.className = erro ? "checkout-aviso erro" : "checkout-aviso";
        }
    };
    function renderizarResumo() {
        const lista = $("#checkout-itens");
        const total = itens.reduce((soma, item) => soma + Number(item.preco) * item.quantidade, 0);
        if (!lista) return;
        lista.replaceChildren();
        const confirmacao = $("#checkout-itens-confirmacao");
        if (confirmacao) confirmacao.replaceChildren();
        itens.forEach(item => {
            const linha = document.createElement("li");
            linha.textContent = `${item.quantidade} × ${item.nome} — ${dinheiro(item.preco * item.quantidade)}`;
            lista.appendChild(linha);
            if (confirmacao) {
                const copia = document.createElement("li");
                copia.textContent = linha.textContent;
                confirmacao.appendChild(copia);
            }
        });
        const totalEl = $("#checkout-total");
        if (totalEl) totalEl.textContent = dinheiro(total);
    }
    function mostrarEtapa(numero) {
        estado.etapa = numero;
        document.querySelectorAll("[data-checkout-etapa]").forEach(el => {
            el.hidden = Number(el.dataset.checkoutEtapa) !== numero;
        });
        document.querySelectorAll("[data-etapa-indicador]").forEach(el => {
            el.classList.toggle("ativo", Number(el.dataset.etapaIndicador) === numero);
        });
        renderizarResumo();
    }
    function validarEtapaAtual() {
        if (estado.etapa === 1 && !itens.length) {
            aviso("Seu carrinho está vazio.", true);
            return false;
        }
        if (estado.etapa === 2 && estado.tipoEntrega === "entrega" && !estado.endereco) {
            aviso("Informe o endereço de entrega.", true);
            return false;
        }
        if (estado.etapa === 3 && !estado.pagamento) {
            aviso("Escolha uma forma de pagamento.", true);
            return false;
        }
        return true;
    }
    async function finalizarPedido() {
        if (!validarEtapaAtual()) return;
        const botao = $("#checkout-finalizar");
        if (botao) botao.disabled = true;
        aviso("Enviando pedido...");
        try {
            const cafeteriaId = await window.obterCafeteriaPadrao();
            const rotulosPagamento = {
                pix: "PIX",
                cartao: "Cartão",
                dinheiro: "Dinheiro"
            };
            const observacoesComPagamento = [ estado.observacoes, `Forma de pagamento preferida: ${rotulosPagamento[estado.pagamento] || estado.pagamento}` ].filter(Boolean).join("\n");
            const pedidoId = await window.criarPedidoSeguro(cafeteriaId, estado.tipoEntrega, estado.endereco, observacoesComPagamento, itens.map(item => ({
                produto_id: item.produto_id,
                quantidade: item.quantidade,
                observacoes: item.observacoes || ""
            })));
            window.carrinhoStore.salvarCarrinho(sessao.user.id, []);
            aviso("Pedido finalizado com sucesso.");
            const destino = `../cliente.html?pedido=${encodeURIComponent(pedidoId)}`;
            setTimeout(() => window.location.replace(destino), 600);
        } catch (erro) {
            console.error(erro);
            aviso(erro.message || "Não foi possível finalizar o pedido.", true);
            if (botao) botao.disabled = false;
        }
    }
    window.addEventListener("app:ready", evento => {
        sessao = evento.detail;
        if (!sessao) return;
        const seletorEndereco = $("#endereco-entrega");
        if (seletorEndereco && window.carregarEnderecosCliente) {
            window.carregarEnderecosCliente().then(enderecos => {
                enderecos.forEach(endereco => {
                    const option = document.createElement("option");
                    option.value = endereco.id;
                    option.textContent = endereco.nome_endereco || [ endereco.rua, endereco.numero, endereco.bairro ].filter(Boolean).join(", ");
                    seletorEndereco.appendChild(option);
                });
            }).catch(erro => console.error("Endereços não carregados:", erro));
        }
        itens = window.carrinhoStore.lerCarrinho(sessao.user.id);
        if (!itens.length) {
            aviso("Adicione produtos ao carrinho antes de continuar.", true);
            return;
        }
        renderizarResumo();
    });
    document.addEventListener("DOMContentLoaded", () => {
        document.querySelectorAll("[data-checkout-proximo]").forEach(botao => botao.addEventListener("click", () => {
            if (validarEtapaAtual()) mostrarEtapa(estado.etapa + 1);
        }));
        document.querySelectorAll("[data-checkout-voltar]").forEach(botao => botao.addEventListener("click", () => mostrarEtapa(Math.max(1, estado.etapa - 1))));
        document.querySelectorAll("[data-entrega]").forEach(botao => botao.addEventListener("click", () => {
            estado.tipoEntrega = botao.dataset.entrega;
            document.querySelectorAll("[data-entrega]").forEach(item => item.classList.remove("selecionado"));
            botao.classList.add("selecionado");
        }));
        document.querySelectorAll("[data-pagamento]").forEach(botao => botao.addEventListener("click", () => {
            estado.pagamento = botao.dataset.pagamento;
            document.querySelectorAll("[data-pagamento]").forEach(item => item.classList.remove("selecionado"));
            botao.classList.add("selecionado");
        }));
        const endereco = $("#endereco-entrega");
        if (endereco) endereco.addEventListener("change", () => {
            estado.endereco = endereco.value || null;
        });
        const observacoes = $("#observacoes-pedido");
        if (observacoes) observacoes.addEventListener("input", () => {
            estado.observacoes = observacoes.value.trim();
        });
        $("#checkout-finalizar")?.addEventListener("click", finalizarPedido);
        mostrarEtapa(1);
    });
})();
