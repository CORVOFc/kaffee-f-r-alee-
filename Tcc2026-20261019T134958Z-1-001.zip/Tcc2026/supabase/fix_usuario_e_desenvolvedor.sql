



DO $$
DECLARE
  assinatura text;
BEGIN
  FOR assinatura IN
    SELECT oid::regprocedure::text
    FROM pg_proc
    WHERE pronamespace = 'public'::regnamespace
      AND proname = 'usuario_e_desenvolvedor'
  LOOP
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO authenticated', assinatura);
  END LOOP;
END $$;


SELECT
  p.oid::regprocedure AS funcao,
  has_function_privilege('authenticated', p.oid, 'EXECUTE') AS authenticated_tem_execute
FROM pg_proc p
WHERE p.pronamespace = 'public'::regnamespace
  AND p.proname = 'usuario_e_desenvolvedor';
