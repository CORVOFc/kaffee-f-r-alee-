ALTER TABLE public.usuarios_cafeterias
  DROP CONSTRAINT IF EXISTS usuarios_cafeterias_funcao_check;

ALTER TABLE public.usuarios_cafeterias
  ADD CONSTRAINT usuarios_cafeterias_funcao_check
  CHECK (funcao = ANY (ARRAY['gestor'::text, 'desenvolvedor'::text]));

CREATE OR REPLACE FUNCTION public.admin_definir_papel_usuario(
  p_perfil_id uuid,
  p_papel text,
  p_cafeteria_id uuid DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_admin_id uuid;
  v_papel text := lower(trim(coalesce(p_papel, '')));
  v_anterior jsonb;
  v_novo jsonb;
  v_qtd_desenvolvedores bigint;
BEGIN
  v_admin_id := public._perfil_atual_e_desenvolvedor();
  IF v_admin_id IS NULL THEN
    RAISE EXCEPTION 'Ação restrita a desenvolvedor ativo.' USING ERRCODE = '42501';
  END IF;
  PERFORM pg_advisory_xact_lock(6743234::bigint);
  IF p_perfil_id = v_admin_id THEN
    RAISE EXCEPTION 'Não é permitido alterar o próprio papel.' USING ERRCODE = '42501';
  END IF;
  IF v_papel NOT IN ('cliente', 'gestor', 'desenvolvedor') THEN
    RAISE EXCEPTION 'Papel inválido. Use cliente, gestor ou desenvolvedor.' USING ERRCODE = '22023';
  END IF;

  SELECT jsonb_build_object('tipo_usuario', p.tipo_usuario, 'ativo', p.ativo)
  INTO v_anterior
  FROM public.perfis AS p
  WHERE p.id = p_perfil_id
  FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Perfil não encontrado.' USING ERRCODE = 'P0002';
  END IF;

  IF v_papel = 'gestor' THEN
    IF p_cafeteria_id IS NULL OR NOT EXISTS (
      SELECT 1 FROM public.cafeterias AS c WHERE c.id = p_cafeteria_id AND c.ativa IS TRUE
    ) THEN
      RAISE EXCEPTION 'Selecione uma cafeteria ativa para o vínculo de gestor.' USING ERRCODE = '22023';
    END IF;
  END IF;

  IF v_papel <> 'desenvolvedor' AND (
    lower(trim(coalesce(v_anterior->>'tipo_usuario', ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
    OR EXISTS (
      SELECT 1 FROM public.usuarios_cafeterias AS uc
      WHERE uc.usuario_id = p_perfil_id
        AND lower(trim(coalesce(uc.funcao, ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
    )
  ) THEN
    SELECT count(*) INTO v_qtd_desenvolvedores
    FROM public.perfis AS p
    WHERE p.ativo IS TRUE
      AND p.id <> p_perfil_id
      AND (
        lower(trim(coalesce(p.tipo_usuario, ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
        OR EXISTS (
          SELECT 1 FROM public.usuarios_cafeterias AS uc
          WHERE uc.usuario_id = p.id
            AND lower(trim(coalesce(uc.funcao, ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
        )
      );
    IF v_qtd_desenvolvedores = 0 THEN
      RAISE EXCEPTION 'Não é possível remover o último desenvolvedor ativo.' USING ERRCODE = '42501';
    END IF;
  END IF;

  DELETE FROM public.usuarios_cafeterias WHERE usuario_id = p_perfil_id;
  IF v_papel = 'desenvolvedor' THEN
    UPDATE public.perfis SET tipo_usuario = 'desenvolvedor', atualizado_em = now() WHERE id = p_perfil_id;
  ELSIF v_papel = 'gestor' THEN
    UPDATE public.perfis SET tipo_usuario = 'cliente', atualizado_em = now() WHERE id = p_perfil_id;
    INSERT INTO public.usuarios_cafeterias (usuario_id, cafeteria_id, funcao, criado_em)
    VALUES (p_perfil_id, p_cafeteria_id, 'gestor', now());
  ELSE
    UPDATE public.perfis SET tipo_usuario = 'cliente', atualizado_em = now() WHERE id = p_perfil_id;
  END IF;

  v_novo := jsonb_build_object('papel', v_papel, 'cafeteria_id', CASE WHEN v_papel = 'gestor' THEN p_cafeteria_id ELSE NULL END);
  INSERT INTO public.logs_auditoria (usuario_id, acao, entidade, entidade_id, dados_anteriores, dados_novos)
  VALUES (v_admin_id, 'alterar_papel', 'perfis', p_perfil_id, v_anterior, v_novo);
END;
$$;

REVOKE ALL ON FUNCTION public.admin_definir_papel_usuario(uuid, text, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_definir_papel_usuario(uuid, text, uuid) TO authenticated;
