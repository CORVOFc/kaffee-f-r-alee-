





DO $$
DECLARE
  assinatura text;
BEGIN
  FOR assinatura IN
    SELECT oid::regprocedure::text
    FROM pg_proc
    WHERE pronamespace = 'public'::regnamespace
      AND proname IN (
        'usuario_e_gestor_ou_desenvolvedor',
        'usuario_e_desenvolvedor'
      )
  LOOP
    EXECUTE format('ALTER FUNCTION %s SECURITY DEFINER', assinatura);
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC', assinatura);
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO anon', assinatura);
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO authenticated', assinatura);
  END LOOP;
END $$;


SELECT
  p.oid::regprocedure AS funcao,
  has_function_privilege('anon', p.oid, 'EXECUTE') AS anon_tem_execute,
  has_function_privilege('authenticated', p.oid, 'EXECUTE') AS authenticated_tem_execute
FROM pg_proc p
WHERE p.pronamespace = 'public'::regnamespace
  AND p.proname IN (
    'usuario_e_gestor_ou_desenvolvedor',
    'usuario_e_desenvolvedor'
  );
