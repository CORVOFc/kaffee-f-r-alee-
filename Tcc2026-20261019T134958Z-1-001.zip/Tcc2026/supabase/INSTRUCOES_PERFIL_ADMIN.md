# Ativação das operações do perfil

O sistema usa somente três papéis: cliente, gestor e desenvolvedor. O cliente mantém recursos pessoais; o gestor recebe acesso operacional por associação a uma cafeteria ativa; o desenvolvedor tem acesso global de administração. Em `usuarios_cafeterias.funcao`, os únicos valores permitidos são `gestor` e `desenvolvedor`.

Em uma instalação nova, execute `perfil_admin_categorias.sql` no SQL Editor do Supabase com o papel `postgres`. No projeto `tcc_final`, as RPCs administrativas já existiam. A migration incremental `perfil_papeis_apenas_cliente_gestor_desenvolvedor.sql` foi aplicada para restringir `admin_definir_papel_usuario()` aos papéis cliente, gestor e desenvolvedor.

A aplicação no projeto real foi verificada: a constraint aceita somente `gestor` e `desenvolvedor`; a RPC administrativa é `SECURITY DEFINER`, executável por `authenticated` e não por `anon`, e sua definição aceita somente os três papéis. `perfil_garantir_proprio()` continua instalada, também restrita a `authenticated`. Uma migration intermediária consta do histórico de migrations do Supabase e foi supersedida pela migration corretiva; ela não faz parte dos scripts ativos deste pacote.

No painel, “Excluir (desativar)” é uma desativação reversível de `perfis.ativo`, preservando a identidade Auth e registros relacionados. A sessão Auth já aberta não é encerrada por essa operação, mas o guard nega papéis e rotas protegidas quando o perfil está inativo. Exclusão permanente e revogação imediata de sessões exigem uma Edge Function ou serviço de backend com Auth Admin; a chave `service_role` nunca deve ser colocada no navegador. Para reativar uma conta, use o botão “Reativar”.

Categorias podem ser adicionadas, editadas, ordenadas e ativadas/desativadas. A remoção física é recusada quando há produtos vinculados; nesses casos, desative a categoria para manter referências e histórico. Categorias desativadas deixam de aparecer nos produtos carregados pelo cardápio.

A conta desenvolvedora não pode alterar o próprio papel nem se desativar. O banco também impede remover ou desativar o último desenvolvedor ativo. Alterações administrativas geram registros em `logs_auditoria`. As policies atuais de outras consultas não foram modificadas e devem ser conferidas para as leituras de catálogo, pedidos, estoque e música.

## Recuperação de perfil pessoal ausente

Se uma conta Auth não tiver uma linha correspondente em `public.perfis`, o guard chama `public.perfil_garantir_proprio()` antes de emitir `app:ready`. Essa RPC identifica o usuário exclusivamente por `auth.uid()`, cria um perfil próprio com papel inicial `cliente` e nunca aceita ID, papel ou estado ativo enviados pelo navegador. Se o perfil já existir, apenas preenche campos pessoais vazios e preserva seu papel e estado. Para uma instalação nova, a função faz parte de `perfil_admin_categorias.sql`. Um perfil existente desativado não é reativado automaticamente: a página o identifica como “Conta desativada” e as áreas protegidas permanecem inacessíveis até a reativação administrativa.

## Bloqueio no login de conta desativada

Após autenticar, o formulário consulta `perfil_garantir_proprio()` usando a sessão autenticada. Se `ativo` for `false`, a aplicação encerra a sessão, permanece na página de login e apresenta a mensagem de conta desativada. Se o banco estiver indisponível ou não retornar um estado verificável, a sessão também é encerrada e o login não prossegue. Contas ativas continuam para o destino solicitado.
