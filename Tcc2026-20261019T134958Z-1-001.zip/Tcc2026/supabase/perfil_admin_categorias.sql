



CREATE OR REPLACE FUNCTION public._perfil_atual_e_desenvolvedor()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
  SELECT p.id
  FROM public.perfis AS p
  WHERE p.usuario_auth_id = auth.uid()
    AND p.ativo IS TRUE
    AND (
      lower(trim(coalesce(p.tipo_usuario, ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
      OR EXISTS (
        SELECT 1
        FROM public.usuarios_cafeterias AS uc
        WHERE uc.usuario_id = p.id
          AND lower(trim(coalesce(uc.funcao, ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
      )
    )
  LIMIT 1;
$$;
REVOKE ALL ON FUNCTION public._perfil_atual_e_desenvolvedor() FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.admin_listar_perfis()
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_admin_id uuid;
  v_resultado jsonb;
BEGIN
  v_admin_id := public._perfil_atual_e_desenvolvedor();
  IF v_admin_id IS NULL THEN
    RAISE EXCEPTION 'Ação restrita a desenvolvedor ativo.' USING ERRCODE = '42501';
  END IF;

  SELECT coalesce(jsonb_agg(
    jsonb_build_object(
      'id', p.id,
      'nome_completo', p.nome_completo,
      'email', p.email,
      'telefone', p.telefone,
      'tipo_usuario', p.tipo_usuario,
      'ativo', p.ativo,
      'criado_em', p.criado_em,
      'usuarios_cafeterias', coalesce(uc.lista, '[]'::jsonb)
    ) ORDER BY p.criado_em DESC
  ), '[]'::jsonb)
  INTO v_resultado
  FROM public.perfis AS p
  LEFT JOIN LATERAL (
    SELECT jsonb_agg(jsonb_build_object('id', c.usuario_cafeteria_id, 'cafeteria_id', c.cafeteria_id, 'funcao', c.funcao)) AS lista
    FROM (
      SELECT u.id AS usuario_cafeteria_id, u.cafeteria_id, u.funcao
      FROM public.usuarios_cafeterias AS u
      WHERE u.usuario_id = p.id
      ORDER BY u.criado_em
    ) AS c
  ) AS uc ON true;

  RETURN v_resultado;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_listar_cafeterias()
RETURNS TABLE (id uuid, nome text, ativa boolean)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF public._perfil_atual_e_desenvolvedor() IS NULL THEN
    RAISE EXCEPTION 'Ação restrita a desenvolvedor ativo.' USING ERRCODE = '42501';
  END IF;
  RETURN QUERY
    SELECT c.id, c.nome, c.ativa
    FROM public.cafeterias AS c
    WHERE c.ativa IS TRUE
    ORDER BY c.nome;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_editar_perfil(
  p_perfil_id uuid,
  p_nome_completo text,
  p_telefone text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_admin_id uuid;
  v_anterior jsonb;
  v_novo jsonb;
BEGIN
  v_admin_id := public._perfil_atual_e_desenvolvedor();
  IF v_admin_id IS NULL THEN
    RAISE EXCEPTION 'Ação restrita a desenvolvedor ativo.' USING ERRCODE = '42501';
  END IF;
  IF p_nome_completo IS NULL OR length(trim(p_nome_completo)) = 0 THEN
    RAISE EXCEPTION 'O nome completo é obrigatório.' USING ERRCODE = '22023';
  END IF;

  SELECT jsonb_build_object('nome_completo', p.nome_completo, 'telefone', p.telefone)
  INTO v_anterior
  FROM public.perfis AS p
  WHERE p.id = p_perfil_id
  FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Perfil não encontrado.' USING ERRCODE = 'P0002';
  END IF;

  UPDATE public.perfis
  SET nome_completo = trim(p_nome_completo),
      telefone = nullif(trim(coalesce(p_telefone, '')), ''),
      atualizado_em = now()
  WHERE id = p_perfil_id
  RETURNING jsonb_build_object('nome_completo', nome_completo, 'telefone', telefone) INTO v_novo;

  INSERT INTO public.logs_auditoria (usuario_id, acao, entidade, entidade_id, dados_anteriores, dados_novos)
  VALUES (v_admin_id, 'editar_perfil', 'perfis', p_perfil_id, v_anterior, v_novo);
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_definir_papel_usuario(
  p_perfil_id uuid,
  p_papel text,
  p_cafeteria_id uuid DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_admin_id uuid;
  v_papel text := lower(trim(coalesce(p_papel, '')));
  v_anterior jsonb;
  v_novo jsonb;
  v_qtd_desenvolvedores bigint;
BEGIN
  v_admin_id := public._perfil_atual_e_desenvolvedor();
  IF v_admin_id IS NULL THEN
    RAISE EXCEPTION 'Ação restrita a desenvolvedor ativo.' USING ERRCODE = '42501';
  END IF;
  PERFORM pg_advisory_xact_lock(6743234::bigint);
  IF p_perfil_id = v_admin_id THEN
    RAISE EXCEPTION 'Não é permitido alterar o próprio papel.' USING ERRCODE = '42501';
  END IF;
  IF v_papel NOT IN ('cliente', 'gestor', 'desenvolvedor') THEN
    RAISE EXCEPTION 'Papel inválido. Use cliente, gestor ou desenvolvedor.' USING ERRCODE = '22023';
  END IF;

  SELECT jsonb_build_object('tipo_usuario', p.tipo_usuario, 'ativo', p.ativo)
  INTO v_anterior
  FROM public.perfis AS p
  WHERE p.id = p_perfil_id
  FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Perfil não encontrado.' USING ERRCODE = 'P0002';
  END IF;

  IF v_papel = 'gestor' THEN
    IF p_cafeteria_id IS NULL OR NOT EXISTS (
      SELECT 1 FROM public.cafeterias AS c WHERE c.id = p_cafeteria_id AND c.ativa IS TRUE
    ) THEN
      RAISE EXCEPTION 'Selecione uma cafeteria ativa para o vínculo de gestor.' USING ERRCODE = '22023';
    END IF;
  END IF;

  IF v_papel <> 'desenvolvedor' AND (
    lower(trim(coalesce(v_anterior->>'tipo_usuario', ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
    OR EXISTS (
      SELECT 1 FROM public.usuarios_cafeterias AS uc
      WHERE uc.usuario_id = p_perfil_id
        AND lower(trim(coalesce(uc.funcao, ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
    )
  ) THEN
    SELECT count(*) INTO v_qtd_desenvolvedores
    FROM public.perfis AS p
    WHERE p.ativo IS TRUE
      AND p.id <> p_perfil_id
      AND (
        lower(trim(coalesce(p.tipo_usuario, ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
        OR EXISTS (
          SELECT 1 FROM public.usuarios_cafeterias AS uc
          WHERE uc.usuario_id = p.id
            AND lower(trim(coalesce(uc.funcao, ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
        )
      );
    IF v_qtd_desenvolvedores = 0 THEN
      RAISE EXCEPTION 'Não é possível remover o último desenvolvedor ativo.' USING ERRCODE = '42501';
    END IF;
  END IF;

  DELETE FROM public.usuarios_cafeterias WHERE usuario_id = p_perfil_id;
  IF v_papel = 'desenvolvedor' THEN
    UPDATE public.perfis SET tipo_usuario = 'desenvolvedor', atualizado_em = now() WHERE id = p_perfil_id;
  ELSIF v_papel = 'gestor' THEN
    UPDATE public.perfis SET tipo_usuario = 'cliente', atualizado_em = now() WHERE id = p_perfil_id;
    INSERT INTO public.usuarios_cafeterias (usuario_id, cafeteria_id, funcao, criado_em)
    VALUES (p_perfil_id, p_cafeteria_id, v_papel, now());
  ELSE
    UPDATE public.perfis SET tipo_usuario = 'cliente', atualizado_em = now() WHERE id = p_perfil_id;
  END IF;

  v_novo := jsonb_build_object('papel', v_papel, 'cafeteria_id', CASE WHEN v_papel = 'gestor' THEN p_cafeteria_id ELSE NULL END);
  INSERT INTO public.logs_auditoria (usuario_id, acao, entidade, entidade_id, dados_anteriores, dados_novos)
  VALUES (v_admin_id, 'alterar_papel', 'perfis', p_perfil_id, v_anterior, v_novo);
END;
$$;



CREATE OR REPLACE FUNCTION public.admin_definir_ativo_usuario(
  p_perfil_id uuid,
  p_ativo boolean
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_admin_id uuid;
  v_anterior jsonb;
  v_novo jsonb;
  v_qtd_desenvolvedores bigint;
BEGIN
  v_admin_id := public._perfil_atual_e_desenvolvedor();
  IF v_admin_id IS NULL THEN
    RAISE EXCEPTION 'Ação restrita a desenvolvedor ativo.' USING ERRCODE = '42501';
  END IF;
  PERFORM pg_advisory_xact_lock(6743234::bigint);
  IF p_perfil_id = v_admin_id AND p_ativo IS FALSE THEN
    RAISE EXCEPTION 'Não é permitido desativar a própria conta.' USING ERRCODE = '42501';
  END IF;

  SELECT jsonb_build_object('ativo', p.ativo, 'tipo_usuario', p.tipo_usuario)
  INTO v_anterior
  FROM public.perfis AS p
  WHERE p.id = p_perfil_id
  FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Perfil não encontrado.' USING ERRCODE = 'P0002';
  END IF;

  IF p_ativo IS FALSE AND v_anterior->>'ativo' = 'true' AND (
    lower(trim(coalesce(v_anterior->>'tipo_usuario', ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
    OR EXISTS (
      SELECT 1 FROM public.usuarios_cafeterias AS uc
      WHERE uc.usuario_id = p_perfil_id
        AND lower(trim(coalesce(uc.funcao, ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
    )
  ) THEN
    SELECT count(*) INTO v_qtd_desenvolvedores
    FROM public.perfis AS p
    WHERE p.ativo IS TRUE
      AND p.id <> p_perfil_id
      AND (
        lower(trim(coalesce(p.tipo_usuario, ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
        OR EXISTS (
          SELECT 1 FROM public.usuarios_cafeterias AS uc
          WHERE uc.usuario_id = p.id
            AND lower(trim(coalesce(uc.funcao, ''))) IN ('desenvolvedor', 'developer', 'admin', 'administrador')
        )
      );
    IF v_qtd_desenvolvedores = 0 THEN
      RAISE EXCEPTION 'Não é possível desativar o último desenvolvedor ativo.' USING ERRCODE = '42501';
    END IF;
  END IF;

  UPDATE public.perfis SET ativo = p_ativo, atualizado_em = now() WHERE id = p_perfil_id;
  v_novo := jsonb_build_object('ativo', p_ativo);
  INSERT INTO public.logs_auditoria (usuario_id, acao, entidade, entidade_id, dados_anteriores, dados_novos)
  VALUES (v_admin_id, CASE WHEN p_ativo THEN 'reativar_perfil' ELSE 'desativar_perfil' END, 'perfis', p_perfil_id, v_anterior, v_novo);
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_listar_categorias(p_cafeteria_id uuid)
RETURNS SETOF public.categorias_cardapio
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_admin_id uuid;
  v_actor_id uuid;
BEGIN
  v_admin_id := public._perfil_atual_e_desenvolvedor();
  IF v_admin_id IS NULL THEN
    SELECT p.id INTO v_actor_id
    FROM public.perfis AS p
    WHERE p.usuario_auth_id = auth.uid() AND p.ativo IS TRUE
    LIMIT 1;
    IF v_actor_id IS NULL OR NOT EXISTS (
      SELECT 1 FROM public.usuarios_cafeterias AS uc
      WHERE uc.usuario_id = v_actor_id
        AND uc.cafeteria_id = p_cafeteria_id
        AND lower(trim(coalesce(uc.funcao, ''))) IN ('gestor', 'manager')
    ) THEN
      RAISE EXCEPTION 'Ação restrita ao gestor da cafeteria ou a desenvolvedor.' USING ERRCODE = '42501';
    END IF;
  END IF;
  RETURN QUERY
    SELECT c.* FROM public.categorias_cardapio AS c
    WHERE c.cafeteria_id = p_cafeteria_id
    ORDER BY c.ordem, c.nome;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_criar_categoria(
  p_cafeteria_id uuid,
  p_nome text,
  p_descricao text DEFAULT NULL,
  p_ordem integer DEFAULT 0
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_admin_id uuid;
  v_actor_id uuid;
  v_categoria_id uuid;
BEGIN
  v_admin_id := public._perfil_atual_e_desenvolvedor();
  IF v_admin_id IS NULL THEN
    SELECT p.id INTO v_actor_id FROM public.perfis AS p
    WHERE p.usuario_auth_id = auth.uid() AND p.ativo IS TRUE LIMIT 1;
    IF v_actor_id IS NULL OR NOT EXISTS (
      SELECT 1 FROM public.usuarios_cafeterias AS uc
      WHERE uc.usuario_id = v_actor_id AND uc.cafeteria_id = p_cafeteria_id
        AND lower(trim(coalesce(uc.funcao, ''))) IN ('gestor', 'manager')
    ) THEN RAISE EXCEPTION 'Ação não autorizada para esta cafeteria.' USING ERRCODE = '42501'; END IF;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.cafeterias AS c WHERE c.id = p_cafeteria_id) THEN
    RAISE EXCEPTION 'Cafeteria não encontrada.' USING ERRCODE = 'P0002';
  END IF;
  IF p_nome IS NULL OR length(trim(p_nome)) = 0 THEN
    RAISE EXCEPTION 'O nome da categoria é obrigatório.' USING ERRCODE = '22023';
  END IF;

  INSERT INTO public.categorias_cardapio (cafeteria_id, nome, descricao, ordem, ativa, criado_em, atualizado_em)
  VALUES (p_cafeteria_id, trim(p_nome), nullif(trim(coalesce(p_descricao, '')), ''), coalesce(p_ordem, 0), true, now(), now())
  RETURNING id INTO v_categoria_id;
  INSERT INTO public.logs_auditoria (usuario_id, cafeteria_id, acao, entidade, entidade_id, dados_novos)
  VALUES (coalesce(v_admin_id, v_actor_id), p_cafeteria_id, 'criar_categoria', 'categorias_cardapio', v_categoria_id,
    jsonb_build_object('nome', trim(p_nome), 'descricao', nullif(trim(coalesce(p_descricao, '')), ''), 'ordem', coalesce(p_ordem, 0)));
  RETURN v_categoria_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_editar_categoria(
  p_categoria_id uuid,
  p_nome text,
  p_descricao text,
  p_ordem integer,
  p_ativa boolean
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_admin_id uuid;
  v_actor_id uuid;
  v_cafeteria_id uuid;
  v_anterior jsonb;
  v_novo jsonb;
BEGIN
  v_admin_id := public._perfil_atual_e_desenvolvedor();
  SELECT c.cafeteria_id, jsonb_build_object('nome', c.nome, 'descricao', c.descricao, 'ordem', c.ordem, 'ativa', c.ativa)
  INTO v_cafeteria_id, v_anterior
  FROM public.categorias_cardapio AS c WHERE c.id = p_categoria_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Categoria não encontrada.' USING ERRCODE = 'P0002'; END IF;
  IF v_admin_id IS NULL THEN
    SELECT p.id INTO v_actor_id FROM public.perfis AS p
    WHERE p.usuario_auth_id = auth.uid() AND p.ativo IS TRUE LIMIT 1;
    IF v_actor_id IS NULL OR NOT EXISTS (
      SELECT 1 FROM public.usuarios_cafeterias AS uc
      WHERE uc.usuario_id = v_actor_id AND uc.cafeteria_id = v_cafeteria_id
        AND lower(trim(coalesce(uc.funcao, ''))) IN ('gestor', 'manager')
    ) THEN RAISE EXCEPTION 'Ação não autorizada para esta cafeteria.' USING ERRCODE = '42501'; END IF;
  END IF;
  IF p_nome IS NULL OR length(trim(p_nome)) = 0 THEN
    RAISE EXCEPTION 'O nome da categoria é obrigatório.' USING ERRCODE = '22023';
  END IF;

  UPDATE public.categorias_cardapio
  SET nome = trim(p_nome), descricao = nullif(trim(coalesce(p_descricao, '')), ''),
      ordem = coalesce(p_ordem, 0), ativa = coalesce(p_ativa, false), atualizado_em = now()
  WHERE id = p_categoria_id
  RETURNING jsonb_build_object('nome', nome, 'descricao', descricao, 'ordem', ordem, 'ativa', ativa) INTO v_novo;
  INSERT INTO public.logs_auditoria (usuario_id, cafeteria_id, acao, entidade, entidade_id, dados_anteriores, dados_novos)
  VALUES (coalesce(v_admin_id, v_actor_id), v_cafeteria_id, 'editar_categoria', 'categorias_cardapio', p_categoria_id, v_anterior, v_novo);
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_excluir_categoria(p_categoria_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_admin_id uuid;
  v_actor_id uuid;
  v_cafeteria_id uuid;
  v_anterior jsonb;
BEGIN
  v_admin_id := public._perfil_atual_e_desenvolvedor();
  SELECT c.cafeteria_id, jsonb_build_object('nome', c.nome, 'descricao', c.descricao, 'ordem', c.ordem, 'ativa', c.ativa)
  INTO v_cafeteria_id, v_anterior
  FROM public.categorias_cardapio AS c WHERE c.id = p_categoria_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Categoria não encontrada.' USING ERRCODE = 'P0002'; END IF;
  IF v_admin_id IS NULL THEN
    SELECT p.id INTO v_actor_id FROM public.perfis AS p
    WHERE p.usuario_auth_id = auth.uid() AND p.ativo IS TRUE LIMIT 1;
    IF v_actor_id IS NULL OR NOT EXISTS (
      SELECT 1 FROM public.usuarios_cafeterias AS uc
      WHERE uc.usuario_id = v_actor_id AND uc.cafeteria_id = v_cafeteria_id
        AND lower(trim(coalesce(uc.funcao, ''))) IN ('gestor', 'manager')
    ) THEN RAISE EXCEPTION 'Ação não autorizada para esta cafeteria.' USING ERRCODE = '42501'; END IF;
  END IF;
  IF EXISTS (SELECT 1 FROM public.produtos AS p WHERE p.categoria_id = p_categoria_id) THEN
    RAISE EXCEPTION 'Esta categoria está vinculada a produtos. Desative-a para preservar o catálogo.' USING ERRCODE = '23503';
  END IF;

  DELETE FROM public.categorias_cardapio WHERE id = p_categoria_id;
  INSERT INTO public.logs_auditoria (usuario_id, cafeteria_id, acao, entidade, entidade_id, dados_anteriores)
  VALUES (coalesce(v_admin_id, v_actor_id), v_cafeteria_id, 'excluir_categoria', 'categorias_cardapio', p_categoria_id, v_anterior);
END;
$$;

REVOKE ALL ON FUNCTION public.admin_listar_perfis() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.admin_listar_cafeterias() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.admin_editar_perfil(uuid, text, text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.admin_definir_papel_usuario(uuid, text, uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.admin_definir_ativo_usuario(uuid, boolean) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.admin_listar_categorias(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.admin_criar_categoria(uuid, text, text, integer) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.admin_editar_categoria(uuid, text, text, integer, boolean) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.admin_excluir_categoria(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_listar_perfis() TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_listar_cafeterias() TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_editar_perfil(uuid, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_definir_papel_usuario(uuid, text, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_definir_ativo_usuario(uuid, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_listar_categorias(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_criar_categoria(uuid, text, text, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_editar_categoria(uuid, text, text, integer, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_excluir_categoria(uuid) TO authenticated;


CREATE OR REPLACE FUNCTION public._perfil_atual_ativo()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
  SELECT p.id
  FROM public.perfis AS p
  WHERE p.usuario_auth_id = auth.uid() AND p.ativo IS TRUE
  LIMIT 1;
$$;
REVOKE ALL ON FUNCTION public._perfil_atual_ativo() FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.perfil_listar_enderecos()
RETURNS SETOF public.enderecos_cliente
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_perfil_id uuid;
BEGIN
  v_perfil_id := public._perfil_atual_ativo();
  IF v_perfil_id IS NULL THEN
    RAISE EXCEPTION 'É necessário possuir um perfil ativo.' USING ERRCODE = '42501';
  END IF;
  RETURN QUERY
    SELECT e.* FROM public.enderecos_cliente AS e
    WHERE e.cliente_id = v_perfil_id AND e.ativo IS TRUE
    ORDER BY e.principal DESC, e.criado_em DESC;
END;
$$;

CREATE OR REPLACE FUNCTION public.perfil_salvar_endereco(
  p_endereco_id uuid,
  p_nome_endereco text,
  p_rua text,
  p_numero text,
  p_complemento text,
  p_bairro text,
  p_cidade text,
  p_estado text,
  p_cep text,
  p_principal boolean
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_perfil_id uuid;
  v_endereco_id uuid;
BEGIN
  v_perfil_id := public._perfil_atual_ativo();
  IF v_perfil_id IS NULL THEN
    RAISE EXCEPTION 'É necessário possuir um perfil ativo.' USING ERRCODE = '42501';
  END IF;
  IF coalesce(trim(p_nome_endereco), '') = '' OR coalesce(trim(p_rua), '') = ''
     OR coalesce(trim(p_numero), '') = '' OR coalesce(trim(p_bairro), '') = ''
     OR coalesce(trim(p_cidade), '') = '' OR coalesce(trim(p_estado), '') = ''
     OR coalesce(trim(p_cep), '') = '' THEN
    RAISE EXCEPTION 'Preencha identificação, rua, número, bairro, cidade, estado e CEP.' USING ERRCODE = '22023';
  END IF;

  IF p_principal IS TRUE THEN
    UPDATE public.enderecos_cliente
    SET principal = false, atualizado_em = now()
    WHERE cliente_id = v_perfil_id AND ativo IS TRUE;
  END IF;

  IF p_endereco_id IS NULL THEN
    INSERT INTO public.enderecos_cliente (
      cliente_id, nome_endereco, rua, numero, complemento, bairro, cidade, estado, cep, principal, ativo, criado_em, atualizado_em
    ) VALUES (
      v_perfil_id, trim(p_nome_endereco), trim(p_rua), trim(p_numero), nullif(trim(coalesce(p_complemento, '')), ''),
      trim(p_bairro), trim(p_cidade), trim(p_estado), trim(p_cep), coalesce(p_principal, false), true, now(), now()
    ) RETURNING id INTO v_endereco_id;
  ELSE
    UPDATE public.enderecos_cliente
    SET nome_endereco = trim(p_nome_endereco), rua = trim(p_rua), numero = trim(p_numero),
        complemento = nullif(trim(coalesce(p_complemento, '')), ''), bairro = trim(p_bairro),
        cidade = trim(p_cidade), estado = trim(p_estado), cep = trim(p_cep),
        principal = coalesce(p_principal, false), atualizado_em = now()
    WHERE id = p_endereco_id AND cliente_id = v_perfil_id AND ativo IS TRUE
    RETURNING id INTO v_endereco_id;
    IF v_endereco_id IS NULL THEN
      RAISE EXCEPTION 'Endereço não encontrado ou não pertence à conta ativa.' USING ERRCODE = 'P0002';
    END IF;
  END IF;
  RETURN v_endereco_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.perfil_definir_endereco_principal(p_endereco_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_perfil_id uuid;
BEGIN
  v_perfil_id := public._perfil_atual_ativo();
  IF v_perfil_id IS NULL THEN
    RAISE EXCEPTION 'É necessário possuir um perfil ativo.' USING ERRCODE = '42501';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.enderecos_cliente AS e
    WHERE e.id = p_endereco_id AND e.cliente_id = v_perfil_id AND e.ativo IS TRUE
    FOR UPDATE
  ) THEN
    RAISE EXCEPTION 'Endereço não encontrado ou não pertence à conta ativa.' USING ERRCODE = 'P0002';
  END IF;
  UPDATE public.enderecos_cliente
  SET principal = (id = p_endereco_id), atualizado_em = now()
  WHERE cliente_id = v_perfil_id AND ativo IS TRUE;
END;
$$;

CREATE OR REPLACE FUNCTION public.perfil_desativar_endereco(p_endereco_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_perfil_id uuid;
BEGIN
  v_perfil_id := public._perfil_atual_ativo();
  IF v_perfil_id IS NULL THEN
    RAISE EXCEPTION 'É necessário possuir um perfil ativo.' USING ERRCODE = '42501';
  END IF;
  UPDATE public.enderecos_cliente
  SET ativo = false, principal = false, atualizado_em = now()
  WHERE id = p_endereco_id AND cliente_id = v_perfil_id AND ativo IS TRUE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Endereço não encontrado ou não pertence à conta ativa.' USING ERRCODE = 'P0002';
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.perfil_marcar_notificacao_lida(p_notificacao_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_perfil_id uuid;
BEGIN
  v_perfil_id := public._perfil_atual_ativo();
  IF v_perfil_id IS NULL THEN
    RAISE EXCEPTION 'É necessário possuir um perfil ativo.' USING ERRCODE = '42501';
  END IF;
  UPDATE public.notificacoes
  SET lida = true
  WHERE id = p_notificacao_id AND usuario_id = v_perfil_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Notificação não encontrada ou não pertence à conta ativa.' USING ERRCODE = 'P0002';
  END IF;
END;
$$;

REVOKE ALL ON FUNCTION public.perfil_listar_enderecos() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.perfil_salvar_endereco(uuid, text, text, text, text, text, text, text, text, boolean) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.perfil_definir_endereco_principal(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.perfil_desativar_endereco(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.perfil_marcar_notificacao_lida(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.perfil_listar_enderecos() TO authenticated;
GRANT EXECUTE ON FUNCTION public.perfil_salvar_endereco(uuid, text, text, text, text, text, text, text, text, boolean) TO authenticated;
GRANT EXECUTE ON FUNCTION public.perfil_definir_endereco_principal(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.perfil_desativar_endereco(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.perfil_marcar_notificacao_lida(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.perfil_garantir_proprio()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_auth_id uuid := auth.uid();
  v_email text;
  v_metadata jsonb;
  v_nome text;
  v_telefone text;
  v_perfil public.perfis%ROWTYPE;
BEGIN
  IF v_auth_id IS NULL THEN
    RAISE EXCEPTION 'É necessário estar autenticado.' USING ERRCODE = '42501';
  END IF;

  SELECT u.email, u.raw_user_meta_data
  INTO v_email, v_metadata
  FROM auth.users AS u
  WHERE u.id = v_auth_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Usuário autenticado não encontrado.' USING ERRCODE = 'P0002';
  END IF;

  v_nome := coalesce(
    nullif(btrim(v_metadata ->> 'nome_completo'), ''),
    nullif(btrim(v_metadata ->> 'full_name'), ''),
    nullif(btrim(v_metadata ->> 'name'), ''),
    nullif(split_part(coalesce(v_email, ''), '@', 1), ''),
    'Cliente'
  );
  v_telefone := nullif(btrim(coalesce(v_metadata ->> 'telefone', v_metadata ->> 'phone', '')), '');

  INSERT INTO public.perfis AS perfil (
    id,
    usuario_auth_id,
    nome_completo,
    email,
    telefone,
    tipo_usuario,
    ativo,
    criado_em,
    atualizado_em
  )
  VALUES (
    gen_random_uuid(),
    v_auth_id,
    v_nome,
    v_email,
    v_telefone,
    'cliente',
    true,
    now(),
    now()
  )
  ON CONFLICT (usuario_auth_id) DO UPDATE
  SET nome_completo = coalesce(nullif(btrim(perfil.nome_completo), ''), EXCLUDED.nome_completo),
      email = coalesce(nullif(btrim(perfil.email), ''), EXCLUDED.email),
      telefone = coalesce(nullif(btrim(perfil.telefone), ''), EXCLUDED.telefone),
      atualizado_em = now()
  RETURNING * INTO v_perfil;

  RETURN jsonb_build_object(
    'id', v_perfil.id,
    'usuario_auth_id', v_perfil.usuario_auth_id,
    'nome_completo', v_perfil.nome_completo,
    'email', v_perfil.email,
    'telefone', v_perfil.telefone,
    'tipo_usuario', v_perfil.tipo_usuario,
    'ativo', v_perfil.ativo,
    'criado_em', v_perfil.criado_em,
    'atualizado_em', v_perfil.atualizado_em
  );
END;
$$;

REVOKE ALL ON FUNCTION public.perfil_garantir_proprio() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.perfil_garantir_proprio() TO authenticated;

ALTER TABLE public.usuarios_cafeterias
  DROP CONSTRAINT IF EXISTS usuarios_cafeterias_funcao_check;

ALTER TABLE public.usuarios_cafeterias
  ADD CONSTRAINT usuarios_cafeterias_funcao_check
  CHECK (funcao = ANY (ARRAY['gestor'::text, 'desenvolvedor'::text]));
