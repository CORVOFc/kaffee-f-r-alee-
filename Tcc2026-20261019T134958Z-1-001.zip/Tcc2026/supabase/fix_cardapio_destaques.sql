

INSERT INTO public.produto_caracteristicas (produto_id, caracteristica_id)
SELECT p.id, c.id
FROM public.produtos AS p
CROSS JOIN public.caracteristicas_produtos AS c
WHERE lower(c.nome) = 'frios'
  AND (
    lower(p.nome) LIKE '%iced%'
    OR lower(p.nome) LIKE '%frappé%'
    OR lower(p.nome) LIKE '%frappe%'
    OR lower(p.nome) LIKE '%cold brew%'
    OR lower(p.nome) LIKE '%gelado%'
    OR lower(p.nome) LIKE '%limonada%'
    OR lower(p.nome) LIKE '%água saborizada%'
    OR lower(p.nome) LIKE '%agua saborizada%'
  )
ON CONFLICT DO NOTHING;


UPDATE public.produtos
SET destaque = true
WHERE nome IN (
  'Café Espresso',
  'Cappuccino',
  'Iced Latte de Aveia',
  'Bolo de Baunilha',
  'Pão de Fermentação Natural',
  'Coxinha de Frango',
  'Chá Gelado de Hortelã',
  'Coca-Cola Lata',
  'Mousse de Chocolate com Polvilho'
);
